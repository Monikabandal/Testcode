
public class InvalidDonorException extends  Exception {
	
	//que 3 
    public InvalidDonorException(String message) {
        super(message);
    }

	
}