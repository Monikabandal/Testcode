import java.util.Scanner;

public class Que3 {
	Scanner sc=new Scanner(System.in);
	  public void person() throws InvalidDonorException {
		  System.out.println("Enter your Age !!");
			int age=sc.nextInt();
			System.out.println("Enter your weight  !!");
			int weight=sc.nextInt();
		  if((age>=21&&age<=60)||(weight>=40&&weight<=70)) {
			  System.out.println("eligible");}
			  else { throw new InvalidDonorException("Something went wrong in someMethod!");}
		  
		  
	  }
	public static void main(String[] args) {
		
		
	Que3 q= new Que3();
	try {
	    q.person();
	 }catch(InvalidDonorException e){
		 System.out.println("InvalidDonorException");
	 }
		
		

	}

}
