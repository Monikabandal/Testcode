import java.util.Scanner;

public class Que2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter digit !!");
		int N=sc.nextInt();
		int r=0;
		int e=0;
		int o=0;
		while(N!=0){
			r=N%10;
			 
	       if(r%2==0) {
			e=r+e;
			
	       }else{
			o=r+o;
		
			}
	       N=N/10;
		     }
		System.out.println( "Sum of Even digit: " +e);
		System.out.println( "Sum of Even digit: " +o);
		
	}

	
}
